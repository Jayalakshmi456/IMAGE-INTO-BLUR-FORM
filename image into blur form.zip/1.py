import cv2

# Load the image
image_path = 'your_image.jpg'  # Replace with your image path
image = cv2.imread(image_path)

if image is None:
    print("Error: Could not read the image.")
    exit()

# Apply Gaussian Blur
blurred_image = cv2.GaussianBlur(image, (15, 15), 0)

# Save the blurred image
cv2.imwrite('blurred_image.jpg', blurred_image)

# Display the original and blurred image (optional)
cv
